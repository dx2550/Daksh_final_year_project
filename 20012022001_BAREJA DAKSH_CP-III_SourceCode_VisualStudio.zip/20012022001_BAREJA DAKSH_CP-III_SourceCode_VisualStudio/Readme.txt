Step1:- Install node in your system
Step 2:- Install MongoDB and Mongooes to your system install React by using "npx create-react-app my-app" commnad 
Step 3:- Extract zip file in your system
Step 4:- In file location open cmd
Step 5:- open cmd then type "npm start" command
Step 6:- project start in your default browser