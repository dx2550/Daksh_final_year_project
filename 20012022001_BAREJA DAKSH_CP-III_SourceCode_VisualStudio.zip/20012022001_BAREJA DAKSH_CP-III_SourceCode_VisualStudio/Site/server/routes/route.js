import express from "express";

import {
  createPost,
  updatePost,
  deletePost,
  getPost,
  getAllPosts,
} from "../controller/post-controller.js";
import { uploadImage, getImage } from "../controller/image-controller.js";
import {
  newComment,
  getComments,
  deleteComment,
} from "../controller/comment-controller.js";
import {
  loginUser,
  singupUser,
  logoutUser,
  getUsers,
  deleteUser,
  getUserCount,
  deleteUsers,
} from "../controller/user-controller.js";
import {
  authenticateToken,
  createNewToken,
} from "../controller/jwt-controller.js";

import upload from "../utils/upload.js";
import {
  addReport,
  deleteReport,
  getAllReports,
  getReport,
  getReports,
} from "../controller/report-controller.js";

const router = express.Router();

router.post("/login", loginUser);
router.post("/signup", singupUser);
router.post("/logout", logoutUser);
router.get("/users", getUsers);
router.delete("/user/:userId", deleteUser);
router.get("/get-user-count", getUserCount);
router.delete("/delete-users", deleteUsers);

router.post("/token", createNewToken);

router.post("/create", authenticateToken, createPost);
router.put("/update/:id", authenticateToken, updatePost);
router.delete("/delete/:id", authenticateToken, deletePost);
router.delete("/delete-post/:id", deletePost);

router.get("/post/:id", authenticateToken, getPost);
router.get("/posts", getAllPosts);

router.post("/file/upload", upload.single("file"), uploadImage);
router.get("/file/:filename", getImage);

router.post("/comment/new", authenticateToken, newComment);
router.get("/comments/:id", authenticateToken, getComments);
router.delete("/comment/delete/:id", authenticateToken, deleteComment);

router.post("/report/:postId", authenticateToken, addReport);
router.get("/report/:postId/:reportId", authenticateToken, getReport);
router.get("/reports/:postId", authenticateToken, getReports);
router.delete("/report/:postId/:reportId", deleteReport);

router.get("/reports", getAllReports);

export default router;
