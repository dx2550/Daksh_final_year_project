// ----------------------------------------------------------------------

const account = {
  displayName: 'Daksh',
  email: 'bareajdaksh2550@gmail.com',
  photoURL: '/assets/images/avatars/avatar_default.jpg',
};

export default account;
