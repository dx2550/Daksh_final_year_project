export { default } from './ScrollToTop';
